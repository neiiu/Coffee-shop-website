<!DOCTYPE html>
<html>
<head>
  <title>消息公版</title>
  <style>
    /* 設定不同的背景樣式 */
    .bg-style-1 {
      background-color: lightblue;
    }
    
    .bg-style-2 {
      background-color: lightgreen;
    }
    
    /* 其他樣式設定... */
    
    /* 樣式設定範例 */
    .message-board {
      border: 1px solid gray;
      padding: 20px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <h2>消息公版</h2>
  
  <!-- 選擇背景樣式、節慶、折扣額度 -->
  <label for="bgStyle">背景樣式：</label>
  <select id="bgStyle">
    <option value="bg-style-1">樣式 1</option>
    <option value="bg-style-2">樣式 2</option>
    <!-- 其他選項... -->
  </select>
  
  <br><br>
  
  <label for="festival">節慶：</label>
  <input type="text" id="festival">
  
  <br><br>
  
  <label for="discount">折扣額度：</label>
  <input type="number" id="discount" min="0" max="100">
  
  <br><br>
  
  <!-- 送出按鈕 -->
  <button id="submitBtn">送出</button>
  
  <br><br>
  
  <!-- 顯示消息的區域 -->
  <div id="messageContainer"></div>
  
  <script src="script.js"></script>
</body>
</html>
