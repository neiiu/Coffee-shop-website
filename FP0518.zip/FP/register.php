<?php
ob_start(); // 啟用輸出緩衝

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dobe Cafe | 登入與註冊</title>

    <link rel="stylesheet" href="home.css">
    <!-- JQuery --> <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <!-- Little icon --> <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
    <!-- Bootstrap --> 
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css'>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js'></script>

</head>
<body>
    
<!-- 左選單 -->
<div class="container-all">
    <!-- left -->
    <div class="">
        <!-- nav -->
        <nav id="sidebar">
            <!-- 展開/鎖起來 -->
            <button type="button" id="collapse" class="collapse-btn"><i class="fa-solid fa-paw"></i></button>
            
            <!-- List列表 -->
            <ul class="list-unstyled">
                <p><a href="home.php">Dobe的咖啡豆</a></p>
                
                <li><a href="news.php">營運公告 <i class="fa-solid fa-bullhorn"></i></a></li>

                <li><a href="#sublist" data-bs-toggle="collapse" id="dropdown">門市資訊 <i class="fa-solid fa-shop"></i></a></li> 
                    <!-- 子連結 (約影片20分的時候有提到怎麼做子連結)-->
                    <ul id="sublist" class="list-unstyled collapse"> 
                        <li><a href="taipei.php">台北門市</a></li>
                        <li><a href="zhubei.php">竹北門市</a></li>
                        <li><a href="toufen.php">頭份門市</a></li>
                        <li><a href="zuoying.php">左營門市</a></li>
                    </ul>
                
                <li><a href="menu.php">本期Menu <i class="fa-solid fa-mug-hot"></i></a></li>
                <li><a href="preshop.php">預購商品 <i class="fa-solid fa-cart-shopping"></i></a></li>
                <li><a href="common.php">常見問題 <i class="fa-solid fa-question" style="margin-right:5px"></i></a></li>
                <li><a href="register.php">登入/註冊<i class="fa-solid fa-user" ></i></a></li>
            </ul>
        </nav>
    </div>
<!-- 左選單結束 -->
<!-- 右欄 -->
<div class="container-right" height="2000px">
    <div class="text-center">
    <div class="col">
        <div class="row-sm-2">
            <!-- 右上角一整組的 -->
        <nav>
            <ul>
                <div>
                    <li class="login-status">
                        <span><?php 
                            session_start();
                            echo isset($_COOKIE['loginStatus']) && $_COOKIE['loginStatus'] === '已登入' && isset($_SESSION['username']) ? 'Hi, ' . $_SESSION['username'] : '訪客'; 
                        ?></span>
                    </li>
                </div>
                <!-- logout -->
                <form action="register.php" method="POST" class="logout-form">
                    <?php 
                        $isLoggedIn = isset($_SESSION['username']);
                    ?>
                    <!-- <input type="submit" name="logout" value="登出" class="logout-button"> -->
                    

                    <?php if ($isLoggedIn) { ?>
                        
                        <input type="submit" name="logout" value="登出" class="logout-button">
                    <?php } else { ?>
                        
                        <input type="submit" name="login" value="登入" class="login-button">
                    <?php } ?>
                </form>


                <div class="shppping-cart">
                    <a href="shoppingCart.php"><li>
                    <i class="fa-solid fa-cart-shopping"></i>
                    </li></a> 
                </div>
                
            </ul>
        </nav>
        <!--  -->
            <h1>登入與註冊</h1><br>
        </div>
        <div class="row-sm-8">
            <div  class="registerBorder">
                <div class="row registerMethod">
                    <div class="col-sm-6 button active" id="leftBtn">登入</div>
                    <div class="col-sm-6 button" id="rightBtn">註冊</div>
                </div>
                <!-- copy -->
                    
                    <!--  -->
                    <div id="login">
                    <form action="register.php" method="post" class="form-container">
                    
                    <h2>登入</h2>
                    <div class="form-group">
                        <label for="username">使用者名稱:</label>
                        <input type="text" name="GETusername" id="username" placeholder="username" maxlength="10" required />
                    </div>
                    <div class="form-group">
                        <label for="password">密碼:</label>
                        <input type="password" name="GETpassword" id="password"  placeholder="password" maxlength="10" required />
                    </div>
                    <div class="form-group button-group">
                        <input type="reset" class="reset-btn" value="重設">
                        <input type="submit" class="submit-btn" name='Loginsubmit' value="登入">
                    </div>
                    </form>
                    </div>

                    <div id="register">
                    <form action="" method="post" class="form-container">
                    <h2>註冊</h2>
                    <div class="form-group">
                        <label for="account">使用者名稱:</label>
                        <input type="text" name="username" placeholder="username" id="username" required />
                    </div>
                    <div class="form-group">
                        <label for="account">密碼:</label>
                        <input type="password" name="password" placeholder="password" id="password" required />
                    </div>
                    <div class="form-group">
                        <label for="name">姓名:</label>
                        <input type="text" name="name" placeholder="name" id="name" required />
                    </div>
                    <div class="form-group">
                        <label for="phone">手機:</label>
                        <input type="text" name="phone" placeholder="phone" id="phone" required />
                    </div>
                    <div class="form-group">
                        <label for="gmail">Gmail:</label>
                        <input type="text" name="gmail" placeholder="Gmail" id="gmail" required />
                    </div>
                    <div class="form-group button-group">
                        <input type="reset" value="重設" class="reset-btn">
                        <input type="submit" value="送出" name='Registersubmit' class="submit-btn">
                    </div>
                    </form>
                    </div>
                    <br>
                    
                    <!--  -->
            </div>
        </div>
        <div>
                    <?php
                    //register
                    
                    
                        $servername ='localhost';
                        $dbname = '登入';
                        $username = 'root';
                        $password = '';
                        $link = @mysqli_connect($servername,$username,$password,$dbname);
                        if(isset($_POST['username'])){
                            $username = $_POST['username'];
                        }
                        if(isset($_POST['password'])){
                            $password = $_POST['password'];
                        }
                        if(isset($_POST['name'])){
                            $name = $_POST['name'];
                        }
                        if(isset($_POST['phone'])){
                            $phone = $_POST['phone'];
                        }
                        if(isset($_POST['gmail'])){
                            $gmail = $_POST['gmail'];
                        }
                        
                        
                        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($registersubmit) ) {
                                $checkgmail= "SELECT * FROM register WHERE gmail = '$gmail'";
                                $gmailresult = $link->query($checkgmail);
                                $checkusername = "SELECT * FROM register WHERE username = '$username'";
                                $usernameresult = $link->query($checkusername);
                                
                                if ($gmailresult->num_rows > 0) {
                                    // 電子信箱已存在，顯示錯誤訊息給使用者
                                    echo "電子信箱已經註冊過，請選擇其他電子信箱";
                                }
                                else if($usernameresult->num_rows > 0){
                                    // 使用者已存在，顯示錯誤訊息給使用者
                                    echo "使用者已經註冊過，請選擇其他使用者名稱";
                                }
                                
                                else{
                                    //gmail
                                    $sql = "INSERT INTO register (username, password, name, phone, gmail) VALUES ('$username', '$password', '$name', '$phone', '$gmail')";
                                    if ($link->query($sql) == TRUE) {
                                        
                                    echo "註冊成功";
                                    // 隱藏登入表單
                                    echo "<script>document.getElementById('register').style.display = 'none';</script>";
                                    } else {
                                        echo "註冊失敗: " . $link->error;
                                    }
                                }
                            }
                             //login
                            if(isset($_POST['Loginsubmit'])){
                                $loginsubmit = $_POST['Loginsubmit'];}
                            if(isset($_POST['Registersubmit'])){
                                $registersubmit = $_POST['Registersubmit'];}

                            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Loginsubmit']) ) {
                                if(isset($_POST['GETusername'])){
                                    $GETusername = $_POST['GETusername'];
                                }
                                if(isset($_POST['GETpassword'])){
                                    $GETpassword = $_POST['GETpassword'];
                                }
                                $loginusername= "SELECT * FROM register WHERE username = '$GETusername'";
                                //此行建立了一個 SQL 查詢語句的字串變數 $loginusernames
                                $usernameresult = $link->query($loginusername);
                                //$link->query() 是使用 PDO 物件的方法，用於執行 SQL 查詢。
                                $loginpassword= "SELECT * FROM register WHERE password = '$GETpassword'";
                                $passwordresult = $link->query($loginpassword);
                                if($usernameresult->num_rows>0 && $passwordresult->num_rows>0){
                                    echo "登入成功";
                                    // 隱藏登入表單
                                    $_SESSION['username'] = $_POST['GETusername'];
                                    // echo $_SESSION['username'];
                                    setcookie("loginStatus", "已登入", time() + 86400, "/");
                                    
                                    echo "<script>document.getElementById('login').style.display = 'none';</script>";
                                    echo "<script>document.cookie = 'loginStatus=已登入';</script>";

                                    // if (isset($_COOKIE['loginStatus']) && $_COOKIE['loginStatus'] === '已登入') {
                                    //     echo "<script>document.getElementsByClassName('login-status')[0].innerHTML = '<span>Hi, </span>'".$GETusername;"</script>";
                                    // }
                                    // echo "<script>document.getElementsByClassName('login-status')[0].innerHTML = '<span>Hi, ".$GETusername."</span>';</script>";
                                }
                            }
                        
                            // 檢查是否已經登入
                            if (isset($_POST['logout'])) {
                                // 檢查是否已經登入
                                if (isset($_SESSION['username'])) {
                                    // 清除登入相關的 Session 和 Cookie
                                    unset($_SESSION['username']);
                                    unset($_COOKIE['loginStatus']);
                                    unset($_COOKIE['loginStatus']);
                                    setcookie("loginStatus", "", time() - 3600, "/");
                                    echo "<script>document.cookie = 'loginStatus=已登入';</script>";
                                }
                            }

                           
                            

                            $link->close();

                        
                    ?>
                    </div>
                    
        <hr>

        <div class="row-sm-2 contact">
            <!-- left -->
            <br><h3>聯絡Dobe的咖啡豆</h3><br>
            <div>

                <div class="ig"><img src="photos/instagram.png" alt="Instagram"><b>Instagram</b> <a href="https://www.instagram.com/">Dobe Cafe</a></div><br>
                <div class="fb"><img src="photos/facebook.png" alt="Facebook"><b>Facebook</b> <a href="https://www.facebook.com/">Dobe Cafe</a></div><br>
                <div class="twitter"><img src="photos/twitter.png" alt="Twitter"><b>Twitter</b> <a href="https://twitter.com/?lang=zh-Hant">Dobe Cafe</a></div><br>
                
            </div>
            <!-- right -->
                <div class="gmail"><img src="photos/gmail.png" alt="Gmail"><b>Gmail:</b> DobeCafe@gmail.com</div><br>
                <div><b>客服時間:</b>  9am-12pm ; 1pm-6pm (假日及國定假日除外)</div>
                <div><b>客服專線：</b> 09-9999-9999 ( 不提供訂位、保留/預訂蛋糕 )</div>
        </div>
    </div>
</div>
</div>
<!-- 右欄 -->
</div>


<script src="register.js"></script>

</body>

</html>