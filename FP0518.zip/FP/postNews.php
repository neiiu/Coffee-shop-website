<?php
// 检查表单提交是否发生
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 检查每个表单字段是否存在并且具有值
    $festivals = isset($_POST['festivals']) ? $_POST['festivals'] : '';
    $discount = isset($_POST['discount']) ? $_POST['discount'] : '';
    $startDate = isset($_POST['startDate']) ? $_POST['startDate'] : '';
    $endDate = isset($_POST['endDate']) ? $_POST['endDate'] : '';
    $period = isset($_POST['postDate']) ? $_POST['postDate'] : '';
    $customers = isset($_POST['customers']) ? $_POST['customers'] : '';
    $additional = isset($_POST['additional']) ? $_POST['additional'] : '';
    // $postOrder = isset($_POST['postOrder']) ? $_POST['postOrder'] : '';
    // 建立数据库连接
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "登入";

    $connection = new mysqli($servername, $username, $password, $dbname);

    // 检查数据库连接是否成功
    if ($connection->connect_error) {
        die("数据库连接失败: " . $connection->connect_error);
    }
    $sql = "SELECT COUNT(*) as total FROM postnews";
    $result = $connection->query($sql);
    date_default_timezone_set("Asia/Taipei");
    $currentDate = date("Y-m-d H:i:s");
    
    echo $currentDate;
    $row = $result->fetch_assoc();
    $totalRows = $row['total'];
    $sql = "INSERT INTO postnews (festivals, discount, startDate, endDate, customers, postDate, additional, postOrder) 
        VALUES ('$festivals', '$discount', '$startDate', '$endDate', '$customers', '$currentDate', '$additional', $totalRows)";

    if ($connection->query($sql) === TRUE) {
        echo "New record inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }

    // $currentDate = date("Y-m-d");
    // $stmt = $connection->prepare("INSERT INTO postnews (festivals, discount, startDate, endDate, customers, postDate, additional, postOrder) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

    // $stmt->bind_param("sssssssi", $festivals, $discount, $startDate, $endDate, $customers, $currentDate, $additional, $totalRows);
    // $stmt->execute();

    // 关闭数据库连接
    // $stmt->close();

    $connection->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>消息處理</title>
    <link rel="stylesheet" href="home.css">
    <style>
        body {
            background-color: #F0E68C;
            /* 鹅黄色 */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            width: 100%;
            justify-content: center;
            /* 将表单容器水平居中 */
            align-items: flex-start;
            /* 将表单容器顶部对齐 */
            height: 100vh;
            padding-top: 50px;
            padding-right:800px;
        }
      
        .details-container {
            width: 30%;
            padding-right:300px;
        }
        
        .form-container {
            /* width: 50%; */
            width: 400px;
            padding: 30px;
            margin-right:50px;
            padding-right:-10px;
            background-color: #FFFFFF;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .form-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-container input[type="text"],
        .form-container input[type="date"],
        .form-container textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #CCC;
            border-radius: 3px;
        }

        .form-container input[type="button"],
        .form-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #4CAF50;
            color: #FFF;
            font-weight: bold;
            cursor: pointer;
        }

        #preview {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #CCC;
            border-radius: 3px;
            background-color: #F9F9F9;
        }

        

        .button-container {
            margin-top: 10px;
            display: flex;
            gap: 10px;
            /* width: 100%; */
            padding: 10px;
            border: none;
            background-color: #4CAF50;
            color: #FFF;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container" id="container">
        <div class="form-container">
            <form action="" method="POST">
                <!-- <form action="" method="POST"> -->
                <h1>News</h1>
                <label for="festivals">節慶：</label>
                <input type="text" name="festivals" id="festivals" required placeholder="優惠節日">
                <br>

                <label for="discount">優惠：</label>
                <input type="text" name="discount" id="discount" required placeholder="優惠額度">
                <br>

                <label for="startDate">活動開始日：</label>
                <input type="date" name="startDate" id="startDate" required placeholder="活動開始日">
                <br>

                <label for="endDate">活動結束日：</label>
                <input type="date" name="endDate" id="endDate" required placeholder="活動結束日">
                <br>

                <label for="customers">顧客：</label>
                <input type="text" name="customers" id="customers" required placeholder="目標顧客">
                <br>

                <label for="additional">其他資訊：</label>
                <textarea name="additional" id="additional" rows="4" required placeholder="補充內容"></textarea>
                <br>

                <div class="button-container">
                    <input type="button" value="重整" onclick="reLoad()">
                    <input type="button" value="預覽" onclick="previewForm()">
                    <input type="submit" value="發布公告">
                </div>
                <br>
                <div id="preview"></div>
            </form>
        </div>

        <div class="details-container">
            <?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "登入";

            $connection = new mysqli($servername, $username, $password, $dbname);

            // 检查数据库连接是否成功
            if ($connection->connect_error) {
                die("数据库连接失败: " . $connection->connect_error);
            }

            // 查询postNews表中的数据
            $query = "SELECT * FROM postnews ORDER BY postOrder DESC";
            $result = $connection->query($query);
            if (!$result) {
                die("查询错误: " . $connection->error);
            }


            if ($result && $result->num_rows > 0) {

                $rows = $result->fetch_all(MYSQLI_ASSOC);
                // $rows = array_reverse($rows); // 反转数组顺序
            
                foreach ($rows as $row) {
                    // 在此处显示公告的相关信息
                    echo '<div class="notice">';
                    echo '<h3>新公告</h3>';
                    echo '<p><span class="label">節慶：</span>' . $row["festivals"] . '</p>';
                    echo '<p><span class="label">優惠：</span>' . $row["discount"] . '</p>';
                    echo '<p><span class="label">起始日：</span>' . $row["startDate"] . '</p>';
                    echo '<p><span class="label">截止日：</span>' . $row["endDate"] . '</p>';
                    echo '<p><span class="label">顧客：</span>' . $row["customers"] . '</p>';
                    echo '<p><span class="label">發布日期：</span>' . $row["postDate"] . '</p>';
                    echo '<p><span class="label">其他資訊：</span>' . $row["additional"] . '</p>';
                    echo '<p><span class="label">序號：</span>' . $row["postOrder"] . '</p>';
                    echo '</div>';
                }
            } else {
                echo '<p class="no-notice">暫無公告</p>';
            }

            // 关闭数据库连接
            $connection->close();
            ?>
        </div>
    </div>

</body>
<script>
    function previewForm() {
        var festivals = document.getElementById("festivals").value;
        var discount = document.getElementById("discount").value;
        var startDate = document.getElementById("startDate").value;
        var endDate = document.getElementById("endDate").value;
        var customers = document.getElementById("customers").value;
        var additional = document.getElementById("additional").value;
        var previewContent = "";

        // 生成预览内容
        previewContent += "<strong>節慶：</strong>" + festivals + "<br>";
        previewContent += "<strong>優惠：</strong>" + discount + "<br>";
        previewContent += "<strong>起始日：</strong>" + startDate + "<br>";
        previewContent += "<strong>截止日：</strong>" + endDate + "<br>";
        previewContent += "<strong>顧客：</strong>" + customers + "<br>";
        previewContent += "<strong>其他資訊：</strong>" + additional + "<br>";

        // 显示预览内容
        document.getElementById("preview").innerHTML = previewContent;

    }
    function reLoad() {
        // 获取当前页面的 URL
        var currentPageUrl = "postNews.php";

        // 重定向到当前页面的 URL
        window.location.href = currentPageUrl;
    }
</script>

</html>