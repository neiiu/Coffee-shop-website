// // Get all the delete buttons
// var deleteButtons = document.querySelectorAll('.btn-danger');

// // Add event listeners to each delete button
// deleteButtons.forEach(function(button) {
//   button.addEventListener('click', function() {
//     // Get the parent cart item element
//     var cartItem = button.parentElement;
//     // Remove the cart item from the cart
//     cartItem.remove();
//     // Update the cart data and display
//     updateCart();
//   });
// });

// // Get all the quantity input fields
// var quantityInputs = document.querySelectorAll('.quantity-input');

// // Add event listeners to each quantity input field
// quantityInputs.forEach(function(input) {
//   input.addEventListener('change', function() {
//     // Get the parent cart item element
//     var cartItem = input.parentElement.parentElement;
//     // Get the new quantity value
//     var newQuantity = input.value;
//     // Update the cart data and display
//     updateCart();
//   });
// });

// // Get all the plus and minus buttons
// var quantityButtons = document.querySelectorAll('.quantity-btn');

// // Add event listeners to each plus and minus button
// quantityButtons.forEach(function(button) {
//   button.addEventListener('click', function() {
//     console.log('quantityGOT');
//     // Get the parent cart item element
//     var cartItem = button.parentElement.parentElement;
//     // Get the current quantity value
//     var quantityInput = cartItem.querySelector('.quantity-input');
//     var currentQuantity = parseInt(quantityInput.value);
//     // Get the new quantity value
//     var newQuantity = currentQuantity;
//     if (button.classList.contains('plus')) {
//       newQuantity++;
//     } else if (button.classList.contains('minus')) {
//       newQuantity--;
//     }
//     // Update the quantity input field
//     quantityInput.value = newQuantity;
//     // Update the cart data and display
//     updateCart();
//   });
// });
function removeCartItem(index) {
  // 发送AJAX请求或通过表单提交将索引发送到服务器端进行删除操作
  // 在此处编写你的删除购物车项的逻辑
  // 例如，可以使用jQuery的AJAX函数发送请求：
  $.ajax({
      url: 'removeCartItem.php', // 替换为处理删除操作的服务器端脚本路径
      type: 'POST',
      data: {index: index},
      success: function(response) {
          // 处理成功删除购物车项后的操作，例如刷新购物车内容或更新总计金额等
      },
      error: function(xhr, status, error) {
          // 处理请求错误的操作
      }
  });
}
