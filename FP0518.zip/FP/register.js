$(document).ready(function(){
    $("#collapse").on("click",function(){
        $("#sidebar").toggleClass("active");
        // $(".fa-solid fa-xmark").toggleClass("fa-bars"); //<i class="fa-solid fa-bars"></i>
        $(".fa-xmark").toggleClass("fa-bars"); //<i class="fa-regular fa-circle-left"></i>
        $(".fa-xmark").toggleClass("fa-bars");
    })
})
//register and login
//Btn
const left = document.querySelector('.button#leftBtn');
const right = document.querySelector('.button#rightBtn');
//box
const login = document.getElementById('login');
const register = document.getElementById('register');
right.addEventListener('click',function(){
    console.log('clicked');
    console.log(right);
    console.log(register);
    register.classList.add('active');
    login.classList.add('active');
    
})
left.addEventListener('click',function(){
    console.log('clicked');
    console.log(left);
    console.log(login);
    login.classList.remove('active');
    register.classList.remove('active');
    
})

document.addEventListener("DOMContentLoaded", function() {
    var leftBtn = document.getElementById("leftBtn");
    var rightBtn = document.getElementById("rightBtn");

    leftBtn.addEventListener("click", function() {
        leftBtn.classList.add("active");
        rightBtn.classList.remove("active");
    });

    rightBtn.addEventListener("click", function() {
        rightBtn.classList.add("active");
        leftBtn.classList.remove("active");
    });
});

$(document).ready(function() {
    $('.logout-form').on('submit', function() {
      location.reload(); // 刷新页面
    });

    $('.login-form').on('submit', function() {
      location.reload(); // 刷新页面
    });
  });

