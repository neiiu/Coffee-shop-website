<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DobeCafe | News</title>
    <link rel="stylesheet" href="home.css">
    <!-- JQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <!-- Little icon -->
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
    <!-- Bootstrap -->
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css'>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js'></script>
    <style>
        .notice {
            flex;
            position:relative;
            left:160px;
            background-color: #a9a9a9a9;
            width: 800px;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
            color: white;
           
        }

        /* .notice h3 {
            margin: 0;
            font-size: 18px;
            color: white;
            font-weight: bold;
            margin-bottom: 10px;
        }*/

        .notice p {
            margin: 0;
            color: #292421;
            font-size: 14px;
            margin-bottom: 5px;
        }
        /*
        .notice .label {
            font-weight: bold;
        } */
    </style>
</head>

<body>
    <!-- 左選單 -->
    <div class="container-all">
        <!-- left -->
        <div class="">
            <!-- nav -->
            <nav id="sidebar">
                <!-- 展開/鎖起來 -->
                <button type="button" id="collapse" class="collapse-btn"><i class="fa-solid fa-paw"></i></button>

                <!-- List列表 -->
                <ul class="list-unstyled">
                    <p><a href="home.php">Dobe的咖啡豆</a></p>

                    <li><a href="news.php">營運公告 <i class="fa-solid fa-bullhorn"></i></a></li>

                    <li><a href="#sublist" data-bs-toggle="collapse" id="dropdown">門市資訊 <i
                                class="fa-solid fa-shop"></i></a></li>
                    <!-- 子連結 (約影片20分的時候有提到怎麼做子連結)-->
                    <ul id="sublist" class="list-unstyled collapse">
                        <li><a href="taipei.php">台北門市</a></li>
                        <li><a href="zhubei.php">竹北門市</a></li>
                        <li><a href="toufen.php">頭份門市</a></li>
                        <li><a href="zuoying.php">左營門市</a></li>
                    </ul>

                    <li><a href="menu.php">本期Menu <i class="fa-solid fa-mug-hot"></i></a></li>
                    <li><a href="preshop.php">預購商品 <i class="fa-solid fa-cart-shopping"></i></a></li>
                    <li><a href="common.php">常見問題 <i class="fa-solid fa-question" style="margin-right:5px"></i></a></li>
                    <li><a href="register.php">登入/註冊<i class="fa-solid fa-user"></i></a></li>
                </ul>
            </nav>
        </div>

        <!-- 門市資訊 -->
        <div class="container-right">
            <div class="text-center">
                <div class="col">
                    <div class="row-sm-2">
                        <!-- 右上角一整組的 -->
                        <nav>
                            <ul>
                                <div>
                                    <li class="login-status">
                                        <span>
                                            <?php
                                            session_start();
                                            echo isset($_COOKIE['loginStatus']) && $_COOKIE['loginStatus'] === '已登入' && isset($_SESSION['username']) ? 'Hi, ' . $_SESSION['username'] : '訪客';
                                            ?>
                                        </span>
                                    </li>
                                </div>
                                <!-- logout -->
                                <form action="register.php" method="POST" class="logout-form">
                                    <?php
                                    $isLoggedIn = isset($_SESSION['username']);
                                    ?>
                                    <!-- <input type="submit" name="logout" value="登出" class="logout-button"> -->
                                    <?php if ($isLoggedIn) { ?>
                                        <input type="submit" name="logout" value="登出" class="logout-button">
                                    <?php } else { ?>
                                        <input type="submit" name="login" value="登入" class="login-button">
                                    <?php } ?>
                                </form>


                                <div class="shppping-cart">
                                    <a href="shoppingCart.php">
                                        <li>
                                            <i class="fa-solid fa-cart-shopping"></i>
                                        </li>
                                    </a>
                                </div>

                            </ul>
                        </nav>
                        <!--  -->
                        <h1>最新資訊</h1>
                    </div>
                    <div class="row-sm-8">
                        <div class="details-container">
                            <?php

                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "登入";

                            $connection = new mysqli($servername, $username, $password, $dbname);

                            // 检查数据库连接是否成功
                            if ($connection->connect_error) {
                                die("数据库连接失败: " . $connection->connect_error);
                            }

                            // 查询postNews表中的数据
                            $query = "SELECT * FROM postnews ORDER BY postOrder DESC";
                            $result = $connection->query($query);
                            if (!$result) {
                                die("查询错误: " . $connection->error);
                            }


                            if ($result && $result->num_rows > 0) {

                                $rows = $result->fetch_all(MYSQLI_ASSOC);
                                // $rows = array_reverse($rows); // 反转数组顺序
                            
                                foreach ($rows as $row) {
                                    // 在此处显示公告的相关信息
                                    echo '<div class="notice">';
                                    echo '<h3>新公告</h3>';
                                    echo '<p><span class="label">節慶：</span>' . $row["festivals"] . '</p>';
                                    echo '<p><span class="label">優惠：</span>' . $row["discount"] . '</p>';
                                    echo '<p><span class="label">起始日：</span>' . $row["startDate"] . '</p>';
                                    echo '<p><span class="label">截止日：</span>' . $row["endDate"] . '</p>';
                                    echo '<p><span class="label">顧客：</span>' . $row["customers"] . '</p>';
                                    echo '<p><span class="label">發布日期：</span>' . $row["postDate"] . '</p>';
                                    echo '<p><span class="label">其他資訊：</span>' . $row["additional"] . '</p>';
                                    echo '</div>';
                                }
                            } else {
                                echo '<p class="no-notice">暫無公告</p>';
                            }

                            // 关闭数据库连接
                            $connection->close();
                            ?>
                        </div>

                        <hr>
                        <div class="row-sm-2 contact">
                            <!-- left -->
                            <br>
                            <h3>聯絡Dobe的咖啡豆</h3><br>
                            <div>

                                <div class="ig"><img src="photos/instagram.png" alt="Instagram"><b>Instagram</b> <a
                                        href="https://www.instagram.com/">Dobe Cafe</a></div><br>
                                <div class="fb"><img src="photos/facebook.png" alt="Facebook"><b>Facebook</b> <a
                                        href="https://www.facebook.com/">Dobe Cafe</a></div><br>
                                <div class="twitter"><img src="photos/twitter.png" alt="Twitter"><b>Twitter</b> <a
                                        href="https://twitter.com/?lang=zh-Hant">Dobe Cafe</a></div><br>

                            </div>
                            <!-- right -->
                            <div class="gmail"><img src="photos/gmail.png" alt="Gmail"><b>Gmail:</b> DobeCafe@gmail.com
                            </div><br>
                            <div><b>客服時間:</b> 9am-12pm ; 1pm-6pm (假日及國定假日除外)</div>
                            <div><b>客服專線：</b> 09-9999-9999 ( 不提供訂位、保留/預訂蛋糕 )</div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 門市資訊 -->
        </div>
        <script src="news.js"></script>

</body>

</html>