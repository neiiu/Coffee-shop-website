<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div><a href="postNews.php">發布消息</a></div>
<style>
    /*  */
</style>

<?php
// 建立数据库连接
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "登入";

$connection = new mysqli($servername, $username, $password, $dbname);

// 检查数据库连接是否成功
if ($connection->connect_error) {
    die("数据库连接失败: " . $connection->connect_error);
}

// 查询postNews表中的数据
// $query = "SELECT * FROM postnews";
// $result = $connection->query($query);
$query = "SELECT * FROM your_table ORDER BY postOrder DESC";
$result = $conn->query($query);
if (!$result) {
    die("查询错误: " . $connection->error);
}

// 显示公告列表
// echo "節慶：" . $_POST["festivals"]. "<br>";
// echo "優惠：" . $_POST["discount"] . "<br>";
// echo "起始日:" .$_POST["startDate"]."<br>";
// echo "截止日:" .$_POST["endDate"]."<br>";
// echo "顧客：" . $_POST["customers"] . "<br>";
// // echo "發布日期：" . $_POST["postDate"] . "<br>";
// echo "其他資訊：" . $_POST["additional"] . "<br>";
// // echo "序號" . $totalRows . "<br>";
// echo "<br>";

if ($result&&$result->num_rows > 0) {
    
    $rows = $result->fetch_all(MYSQLI_ASSOC);


    foreach ($rows as $row) {
        // 在此处显示公告的相关信息
        echo "節慶：" . $row["festivals"] . "<br>";
        echo "優惠：" . $row["discount"] . "<br>";
        echo "起始日:" . $row["startDate"] . "<br>";
        echo "截止日:" . $row["endDate"] . "<br>";
        echo "顧客：" . $row["customers"] . "<br>";
        echo "發布日期：" . $row["postDate"] . "<br>";
        echo "其他資訊：" . $row["additional"] . "<br>";
        echo "序號" . $row["postOrder"] . "<br>";
        echo "<br>";
    }
} else {
    echo "暫無公告";
}

// 关闭数据库连接
$connection->close();
?>
</body>
</html>
