$(document).ready(function(){
    $("#collapse").on("click",function(){
        $("#sidebar").toggleClass("active");
        // $(".fa-solid fa-xmark").toggleClass("fa-bars"); //<i class="fa-solid fa-bars"></i>
        $(".fa-xmark").toggleClass("fa-bars"); //<i class="fa-regular fa-circle-left"></i>
        $(".fa-xmark").toggleClass("fa-bars");
    })
})




