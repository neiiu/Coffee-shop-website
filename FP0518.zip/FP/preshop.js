$(document).ready(function(){
    $("#collapse").on("click",function(){
        $("#sidebar").toggleClass("active");
        // $(".fa-solid fa-xmark").toggleClass("fa-bars"); //<i class="fa-solid fa-bars"></i>
        $(".fa-xmark").toggleClass("fa-bars"); //<i class="fa-regular fa-circle-left"></i>
        $(".fa-xmark").toggleClass("fa-bars");
    })
})

// 獲取加減按鈕和輸入框元素
const minusBtns = document.querySelectorAll('.minus');
const plusBtns = document.querySelectorAll('.plus');
const inputs = document.querySelectorAll('input[type="number"]');

// 監聽減按鈕的點擊事件，更新數量
minusBtns.forEach((btn, index) => {
  btn.addEventListener('click', () => {
    console.log("-");
    if (inputs[index].value > inputs[index].min) {
      inputs[index].value--;}

  });
});
// 監聽加按鈕的點擊事件，更新數量
plusBtns.forEach((btn, index) => {
  btn.addEventListener('click', () => {
      console.log("+");
      if (parseInt(inputs[index].value) < parseInt(inputs[index].max)) {
        inputs[index].value++;
      }

  });
});





