<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dobe Cafe | 竹北門市</title>
    <link rel="stylesheet" href="home.css">
    <!-- JQuery --> <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <!-- Little icon --> <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
    <!-- Bootstrap --> 
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css'>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js'></script>
</head>
<body>
    <!-- 左選單 -->
<div class="container-all">
    <!-- left -->
    <div class="">
        <!-- nav -->
        <nav id="sidebar">
            <!-- 展開/鎖起來 -->
            <button type="button" id="collapse" class="collapse-btn"><i class="fa-solid fa-paw"></i></button>
            
            <!-- List列表 -->
            <ul class="list-unstyled">
                <p><a href="home.php">Dobe的咖啡豆</a></p>
                
                <li><a href="news.php">營運公告 <i class="fa-solid fa-bullhorn"></i></a></li>

                <li><a href="#sublist" data-bs-toggle="collapse" id="dropdown">門市資訊 <i class="fa-solid fa-shop"></i></a></li> 
                    <!-- 子連結 (約影片20分的時候有提到怎麼做子連結)-->
                    <ul id="sublist" class="list-unstyled collapse"> 
                        <li><a href="taipei.php">台北門市</a></li>
                        <li><a href="zhubei.php">竹北門市</a></li>
                        <li><a href="toufen.php">頭份門市</a></li>
                        <li><a href="zuoying.php">左營門市</a></li>
                    </ul>
                
                <li><a href="menu.php">本期Menu <i class="fa-solid fa-mug-hot"></i></a></li>
                <li><a href="preshop.php">預購商品 <i class="fa-solid fa-cart-shopping"></i></a></li>
                <li><a href="common.php">常見問題 <i class="fa-solid fa-question" style="margin-right:5px"></i></a></li>
                <li><a href="register.php">登入/註冊<i class="fa-solid fa-user" ></i></a></li>
            </ul>
        </nav>
    </div>
<!-- 左選單結束 -->
<!-- 門市資訊 -->
<div class="container-right" height="2300px">
    <div class="text-center">
    <div class="col">
        <div class="row-sm-2">
             <!-- 右上角一整組的 -->
        <nav>
            <ul>
                <div>
                    <li class="login-status">
                        <span><?php 
                            session_start();
                            echo isset($_COOKIE['loginStatus']) && $_COOKIE['loginStatus'] === '已登入' && isset($_SESSION['username']) ? 'Hi, ' . $_SESSION['username'] : '訪客'; 
                        ?></span>
                    </li>
                </div>
                <!-- logout -->
                <form action="register.php" method="POST" class="logout-form">
                    <?php 
                        $isLoggedIn = isset($_SESSION['username']);
                    ?>
                    <!-- <input type="submit" name="logout" value="登出" class="logout-button"> -->
                    <?php if ($isLoggedIn) { ?>
                        <input type="submit" name="logout" value="登出" class="logout-button">
                    <?php } else { ?>
                        <input type="submit" name="login" value="登入" class="login-button">
                    <?php } ?>
                </form>


                <div class="shppping-cart">
                    <a href="shoppingCart.php"><li>
                    <i class="fa-solid fa-cart-shopping"></i>
                    </li></a> 
                </div>
                
            </ul>
        </nav>
        <!--  -->
            <h1>Dobe Cafe 竹北門市</h1>
            <p>地址:302新竹縣竹北市莊敬北路999號(鄰近竹北遠百)</p>
        </div>
        <div class="row-sm-8">
            <br><img src="photos/zhubei.png" alt="zhubeiBranch" width="400px"><br><br><h5>建築外觀</h5><br>
            <br><img src="photos/zhubei_inner.png" alt="zhubeiBranchInner" width="400px"><br><br><h5>室內</h5><br>
        </div>
        <hr>
        <div class="row-sm-2 contact">
            <!-- left -->
            <br><h3>聯絡Dobe的咖啡豆</h3><br>
            <div>

                <div class="ig"><img src="photos/instagram.png" alt="Instagram"><b>Instagram</b> <a href="https://www.instagram.com/">Dobe Cafe</a></div><br>
                <div class="fb"><img src="photos/facebook.png" alt="Facebook"><b>Facebook</b> <a href="https://www.facebook.com/">Dobe Cafe</a></div><br>
                <div class="twitter"><img src="photos/twitter.png" alt="Twitter"><b>Twitter</b> <a href="https://twitter.com/?lang=zh-Hant">Dobe Cafe</a></div><br>
                
            </div>
            <!-- right -->
                <div class="gmail"><img src="photos/gmail.png" alt="Gmail"><b>Gmail:</b> DobeCafe@gmail.com</div><br>
                <div><b>客服時間:</b>  9am-12pm ; 1pm-6pm (假日及國定假日除外)</div>
                <div><b>客服專線：</b> 09-9999-9999 ( 不提供訂位、保留/預訂蛋糕 )</div>
            </div>
    </div>
</div>
</div>
<!-- 門市資訊 -->
</div>
<script src="index.js"></script>

</body>

</html>