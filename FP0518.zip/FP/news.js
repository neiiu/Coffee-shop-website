$(document).ready(function(){
    $("#collapse").on("click",function(){
        $("#sidebar").toggleClass("active");
        // $(".fa-solid fa-xmark").toggleClass("fa-bars"); //<i class="fa-solid fa-bars"></i>
        $(".fa-xmark").toggleClass("fa-bars"); //<i class="fa-regular fa-circle-left"></i>
        $(".fa-xmark").toggleClass("fa-bars");
    })
})
// news LIST
let title = document.getElementById('title');
let content = document.getElementById('content');
let newsBtn = document.getElementById('newsBtn');
let newsList = document.getElementById('newsList');
newsBtn.addEventListener('click',function(){
    // 從最下面開始加
        // newsList.innerHTML = newsList.innerHTML +`
        // <div class="article">
        //     <h2>${title.value}</h2>
        //     <p>${content.value}</p>
        // </div>
        // ` 
    // 從最上面開始加
        newsList.insertAdjacentHTML('afterbegin', `
        <div class="article">
            <h2>${title.value}</h2>
            <p>${content.value}</p>
        </div>`
        );
        title.value="";
        content.value="";
        
// 教學網址:https://www.youtube.com/watch?v=yZwlW5INhgk
})
localStorage.setItem('news', newsList.innerHTML);
const news = localStorage.getItem('news');
if (news) {
    newsList.innerHTML = news;
}
