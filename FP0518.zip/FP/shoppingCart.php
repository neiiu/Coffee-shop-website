<?php
session_start(); // 启动会话
// session_unset();
// exit();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $img = ["草莓生乳捲","雙莓蛋糕","草莓起酥蛋糕","草莓奶油蛋糕"];
  // 获取产品信息
  if (isset($_POST['productName']) && isset($_POST['productPrice']) && isset($_POST['quantity'])) {
      $productName = $_POST['productName'];
      $productPrice = $_POST['productPrice'];
      $quantity = $_POST['quantity'];
      $image = 'cake/'.$productName.' png';

      if ($quantity > 0) {
          // 检查购物车中是否已经存在相同的商品
        $existingItemIndex = null;
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            $cart = $_SESSION['cart'];
            foreach ($cart as $index => $item) {
                if ($item['productName'] === $productName && $item['productPrice'] === $productPrice) {
                    $existingItemIndex = $index;
                    break;
                }
            }
        }

        // 更新已存在的商品数量或创建新的购物车项
        if ($existingItemIndex !== null) {
            $_SESSION['cart'][$existingItemIndex]['quantity'] += $quantity;
        } else {
            // 创建购物车项数组
            $item = array(
                'productName' => $productName,
                'productPrice' => $productPrice,
                'quantity' => $quantity,
                'image' => 'cake/'.$productName.' png',
            );

          // 将购物车项添加到购物车数组
          if (!isset($_SESSION['cart'])) {
              $_SESSION['cart'] = array();
          }
          $_SESSION['cart'][] = $item;
      }
  }

}
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DobeCafe | 購物車</title>

    <link rel="stylesheet" href="home.css">
    <!-- JQuery --> <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    
    <!-- Little icon --> <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
    <!-- Bootstrap --> 
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css'>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js'></script>
    <style>
        body{
            background-color: rgb(248, 255, 225);
        }
        
        .cart-item-image img {
            max-width: 200px;
            max-height: 200px;
        }
</style>

    </style>
</head>
<body>
<div>
    
    <div class="cart-container"><br>
    <div class="text-center" ><h1>
        <a href="home.php"  class="text-decoration-none d-inline-block" style="color: #526191;">
            <i class="fa-solid fa-paw">Dobe的咖啡豆<i class="fa-solid fa-paw"></i></i>
        </a>
    </h1></div>
    <!-- 結帳流程 -->
    <div class="container">
    <div class="row justify-content-center mt-5">
      <div class="col-md-8">
        <div class="checkout-container">
          <div class="checkout-steps">
            <div class="checkout-step">
              <div class="checkout-step-number">1</div>
              <div class="checkout-step-title">購物車</div>
            </div>
            <div class="checkout-step">
              <div class="checkout-step-number">2</div>
              <div class="checkout-step-title">選擇付款訊息</div>
            </div>
            <div class="checkout-step">
              <div class="checkout-step-number">3</div>
              <div class="checkout-step-title">完成訂單</div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
  <!-- 購物車 -->
  <br>
    <h1 class="cart-header">購物車</h1>
    <div id="cart-container"></div>
        <?php
      if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
  
        $cart = $_SESSION['cart'];
    
        foreach ($cart as $productIndex => $item) {
            $productName = $item['productName'];
            $productPrice = $item['productPrice'];
            $quantity = $item['quantity'];
            $image = 'cake/'.$productName.'.png';
            
    
            // 只在数量大于 0 时显示购物车项
            if ($quantity > 0) {
              // echo "Image: <img src='$image' alt='$productName'><br>";
              // echo "Product: $productName<br>";
              // echo "Price: $productPrice<br>";
              // echo "Quantity: $quantity<br>";
              echo '<div class="cart-item">';
            echo '<div class="cart-item-image">';
            echo '<img src="' . $image . '" alt="' . $productName . '">';
            echo '</div>';
            echo '<div class="cart-item-details">';
            echo '<div class="cart-item-name">' . $productName . '</div>';
            echo '<div class="cart-item-price">Price: ' . $productPrice . '</div>';
            echo '<div class="cart-item-quantity">Quantity: ' . $quantity . '</div>';
            echo '<div class="cart-item-delete">';
            echo '<button class="btn btn-danger">Delete</button>';
            echo '</div>';
            echo '</div>';
            echo '</div>';              
            }
        }
    } else {
        echo "購物車為空";
    }

  ?>
    


    <div class="cart-total">
      <!-- <p>總計: $45.00</p> -->
    </div>
    <!-- 下一步 -->
    <!-- <button id="clear-cart">清空購物車</button> -->
    <div class="text-center">
        <a href="preshop.php"><button class="btn btn-primary">上一步</button></a>
        <button class="btn btn-primary">下一步</button>
    </div>
  </div>
  <script src="shoppingCart.js"></script>
</div>
</body>
</html>