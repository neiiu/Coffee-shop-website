// 恢復並顯示已保存的消息
window.addEventListener('DOMContentLoaded', function() {
    var savedMessages = JSON.parse(localStorage.getItem('messages')) || [];
    
    savedMessages.forEach(function(savedMessage) {
      showMessage(savedMessage.bgStyle, savedMessage.festival, savedMessage.discount);
    });
  });
  
  document.getElementById('submitBtn').addEventListener('click', function() {
    // 獲取選擇的值
    var bgStyle = document.getElementById('bgStyle').value;
    var festival = document.getElementById('festival').value;
    var discount = document.getElementById('discount').value;
    
    // 顯示消息
    showMessage(bgStyle, festival, discount);
    
    // 保存消息到本地儲存
    var savedMessages = JSON.parse(localStorage.getItem('messages')) || [];
    savedMessages.push({ bgStyle: bgStyle, festival: festival, discount:discount });

    localStorage.setItem('messages', JSON.stringify(savedMessages));
    });
    
    function showMessage(bgStyle, festival, discount) {
    // 建立新的消息元素
    var messageElement = document.createElement('div');
    messageElement.classList.add('message-board', bgStyle);
    
    // 設置消息內容
    messageElement.innerHTML = `<h3>${festival}</h3> <p>折扣額度：${discount}% off</p>` ;
    
    // 將消息新增到畫面上
    var messageContainer = document.getElementById('messageContainer');
    messageContainer.appendChild(messageElement);
    }
  
// 從本地儲存中取得已保存的消息
var savedMessages = JSON.parse(localStorage.getItem('messages')) || [];

// 顯示已保存的消息
savedMessages.forEach(function(message) {
  showMessage(message.bgStyle, message.festival, message.discount);
});

// 綁定送出按鈕的點擊事件
submitBtn.addEventListener('click', function(event) {
  event.preventDefault();

  // 取得使用者輸入的值
  var bgStyle = bgStyleSelect.value;
  var festival = festivalInput.value;
  var discount = discountInput.value;

  // 建立新的消息物件
  var newMessage = {
    bgStyle: bgStyle,
    festival: festival,
    discount: discount
  };

  // 將新的消息新增到畫面上
  showMessage(bgStyle, festival, discount);

  // 將新的消息保存到本地儲存中
  savedMessages.push(newMessage);
  localStorage.setItem('messages', JSON.stringify(savedMessages));

  // 清除輸入欄位的值
  festivalInput.value = '';
  discountInput.value = '';
});

function showMessage(bgStyle, festival, discount) {
  // 建立新的消息元素
  var messageElement = document.createElement('div');
  messageElement.classList.add('message-board', bgStyle);
  
  // 設置消息內容
  messageElement.innerHTML = `
    <h3>${festival}</h3>
    <p>折扣額度：${discount}% off</p>
    <button class="delete-btn">刪除</button>
  `;
  
  // 將消息新增到畫面上
  var messageContainer = document.getElementById('messageContainer');
  messageContainer.appendChild(messageElement);
  
  // 綁定刪除按鈕的點擊事件
  var deleteBtn = messageElement.querySelector('.delete-btn');
  deleteBtn.addEventListener('click', function() {
    // 從畫面上移除該消息
    messageContainer.removeChild(messageElement);
    
    // 從本地儲存中移除該消息
    var index = savedMessages.findIndex(function(message) {
      return (
        message.bgStyle === bgStyle &&
        message.festival === festival &&
        message.discount === discount
      );
    });
    if (index !== -1) {
      savedMessages.splice(index, 1);
      localStorage.setItem('messages', JSON.stringify(savedMessages));
    }
  });
}

    

// 這個修改後的示例在頁面載入時，從本地儲存中恢復並顯示已保存的消息。每當使用者提交一條新消息，它將被新增到畫面上並保存到本地儲存中。這樣，即使在刷新頁面後，保存的消息也會被重新顯示出來。

// 請注意，使用瀏覽器的本地儲存（LocalStorage）僅在特定瀏覽器上有效，且僅在特定設備上有效。如果您需要在多個設備或使用不同瀏覽器的不同用戶之間同步消息，則需要使用更高級的解決方案，例如使用資料庫來保存消息。
