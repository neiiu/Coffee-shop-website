<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        // if(isset($_COOKIE["ItemName"])){
        //     $itemName = $_COOKIE["ItemName"];
        //     $quantity = $_COOKIE["Quantity"];
        //     print "取得ItemName的Cookie值: ".$itemName."<br>";
        //     print "取得Quantity的Cookie值: ".$quantity."<br>";
        //     //刪除Cookie
        //     setcookie("ItemName", "",time()-3600);
        //     setcookie("Quantity", "", time()-3600);
        // }
        // else{
        //     $itemName = "白色iphone";
        //     $quantity = "10";
        //     //有效時間為10天後
        //     $date = strtotime("+10 days",time());
        //     setcookie("ItemName", $itemName, $date);
        //     setcookie("Quantity", $quantity, $date);
        //     //顯示建立的資料
        //     print "新增名為ItemName的Cookie: ".$itemName."<br>";
        //     print "新增名為Quantity的Cookie: ".$quantity."<br>";
        //     print "Cookie期限".date("l F j Y h:i:s A",$date);
        // }
        session_start();
        echo "啟用交談期";
        if(!isset($_SESSION["page_counter"])){
            $_SESSION["page_counter"] = 1;
        }
        else{
            $_SESSION["page_counter"]++;
        }
        $value = $_SESSION["page_counter"];
        echo "使用者Session ID:".session_id()."<br>";
        echo "進入網頁次數: $value <br>";
        if($value>5){
            unset($_SESSION["page_counter"]);
            if(!isset($_SESSION["page_counter"])){
                echo "Session變數page_counter不存在！";
                session_destroy();
                echo "關閉交談期";
            }
        }
    ?>
    <!-- <br><a href="cookie.php">取得Cookie值</a> -->
</body>
</html>