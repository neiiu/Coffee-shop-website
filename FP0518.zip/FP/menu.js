'use strict'
$(document).ready(function(){
    $("#collapse").on("click",function(){
        $("#sidebar").toggleClass("active");
        // $(".fa-solid fa-xmark").toggleClass("fa-bars"); //<i class="fa-solid fa-bars"></i>
        $(".fa-xmark").toggleClass("fa-bars"); //<i class="fa-regular fa-circle-left"></i>
        $(".fa-xmark").toggleClass("fa-bars");
    })
})

//menu
// 獲取加減按鈕和輸入框元素
const minusBtns = document.querySelectorAll('.minus');
const plusBtns = document.querySelectorAll('.plus');
const inputs = document.querySelectorAll('input[type="number"]');

// 監聽減按鈕的點擊事件，更新數量
minusBtns.forEach((btn, index) => {
  btn.addEventListener('click', () => {
    console.log("-");
    if (inputs[index].value > inputs[index].min) {
      inputs[index].value--;}

  });
});
// 監聽加按鈕的點擊事件，更新數量
plusBtns.forEach((btn, index) => {
  btn.addEventListener('click', () => {
      console.log("+");
      if (parseInt(inputs[index].value) < parseInt(inputs[index].max)) {
        inputs[index].value++;
      }

  });
});

//list
let listIcon = document.querySelector('#listIcon');
let list = document.querySelector("#list");

listIcon.addEventListener('click', function() {
    console.log('list clicked');
    list.classList.toggle('expanded');
});

//處理加入清單
let addToList = document.querySelectorAll('.add-to-cart');
let orderNum =0;

addToList.forEach((btn,index) => {
  btn.addEventListener('click',()=>{
    console.log("addToList clicked");
    // list.innerHTML +=  
    // `<div>
      
    // </div>`
    //飲料種類
    let drinks = document.querySelectorAll('input[name="name"]');
    
    console.log(drinks);
    //創建菜單的array
    let drinksArray = ["可樂","雪碧","芬達",
    "凍頂烏龍茶(一壺)","紅玉紅茶(一壺)","碧螺春(一壺)",
  "(冰)凍頂烏龍茶(一杯)","(冰)紅玉紅茶(一杯)","(冰)碧螺春(一杯)"];
    console.log(drinksArray);
    //迴圈控制列單出現在清單上
  drinks.forEach((drink,drinkIndex) => {
    if (drinkIndex === index) {
    //price
    let price = drink.parentNode.querySelector('input[name="price"]').value;
    // console.log(drink.value);
    // console.log(addToList[index].value);
    let quantity =document.querySelectorAll('input[type="number"]');
    
    // console.log(quantity);
    if(quantity[index].value>0){
      // console.log('addToList"s value>0');
      // console.log(quantity[index].value);
      for(let i =0;i<drinksArray.length;i++){
        switch(drink.value){
          case drinksArray[i]:
            list.innerHTML +=`<div>
            <span> ${drink.value}:數量:${quantity[index].value}，共${quantity[index].value*price}元
            </span><button class="delete">刪除</button></div>`;
            
            orderNum++;
        }
      }
      
    } 
  }
});

    //清單內的checkbox刪除
    document.querySelectorAll('.delete').forEach((btn) => {
      btn.addEventListener('click', () => {
        btn.parentNode.remove();
      });
    });
  });
});



//0504控制 若新的商品和舊的重複把舊的刪掉
//在清單內可以修改數量,刪除清單,送出清單
